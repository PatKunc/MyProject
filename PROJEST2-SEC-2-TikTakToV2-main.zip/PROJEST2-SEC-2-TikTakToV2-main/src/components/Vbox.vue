<template>
    <div class="mt-0.5 mb-10 mr-10 ml-10 pt-50 pl-50 border-solid border-black border-2 w-11/12 lg:w-1/2 h-80 overflow-auto rounded-md bg-white">
        <slot></slot>
    </div>
</template>